﻿namespace WebApp.Models
{
	public class Address
	{
		public string Country { get; set; }
		public int Pin { get; set; }
	}
}
