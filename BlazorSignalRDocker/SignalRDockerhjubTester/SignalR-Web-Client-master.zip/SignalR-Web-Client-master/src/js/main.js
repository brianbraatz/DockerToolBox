
import 'material-design-lite/material.css'
import 'material-design-lite/material.js'
import '@webcomponents/webcomponentsjs/webcomponents-bundle';//WebComponent Pollyfill
import 'bootstrap/dist/css/bootstrap.css'
import 'bootstrap/dist/js/bootstrap.js'
import '../css/main.css';
// import './components/custom.alertbox';
import './components/srform.component';
import './components/app.component';