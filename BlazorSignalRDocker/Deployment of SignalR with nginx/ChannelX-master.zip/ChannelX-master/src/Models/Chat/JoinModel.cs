using System;

namespace ChannelX.Models.Chat
{
    public class JoinModel
    {
        public int ChannelId { get; set; }
    }
}