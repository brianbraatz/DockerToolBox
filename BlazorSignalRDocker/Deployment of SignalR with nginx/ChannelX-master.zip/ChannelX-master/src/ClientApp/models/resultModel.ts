interface resultModel {
    succeeded: boolean,
    prompt: boolean,
    message: string,
    data: any
}

export default resultModel;