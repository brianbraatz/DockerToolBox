﻿public class LogScopeInfo
{
    public string? Text { get; set; }
    public Dictionary<string, object>? Properties { get; set; }
}
