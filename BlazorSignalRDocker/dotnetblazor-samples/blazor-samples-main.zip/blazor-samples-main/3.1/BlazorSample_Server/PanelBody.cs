﻿public class PanelBody
{
    public string Text { get; set; }
    public string Style { get; set; }
}
