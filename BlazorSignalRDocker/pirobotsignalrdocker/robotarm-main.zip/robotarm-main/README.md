# robotarm

Based on the forked repo jonnychipz/rpirobot, this code repo contains the firmware for the bot arm and the Server/client Blazor WASM and SignalR code.
